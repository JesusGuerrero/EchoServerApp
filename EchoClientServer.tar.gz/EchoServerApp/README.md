EchoServerApp
=============

Coding Challenge



##Behavior-Driven Development (Testing)
The EchoClientServer module has been tested with Jasmine (jasmine-node). Two test cases were conducted, one to test using the default port and the other test using a custom port. For each of these tests we start and stop the server which listens, and also create and destroy a socket connection. The server is closed once we process the data received by the socket and the socket is destroyed right after the custom function handles the response from the server.
